
public class items {
    public String name ;
    public double price ;


        public items(String name, double price ){

            this .name= name;
            this. price= price;

        }
}
