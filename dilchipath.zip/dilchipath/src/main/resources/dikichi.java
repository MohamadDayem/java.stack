
public class dikichi {

}
