public class Device{
    protected int battery = 100;

    protected void status(){
        System.out.println("Battery remaining: "+battery);
    }
}