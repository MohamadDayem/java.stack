public class Mammal {
    public int energyLevel = 100;

    public void displayEnergy() {
        System.out.printf("Current energy level: %d\n", energyLevel);
    }
}
