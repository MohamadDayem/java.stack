package com.javastack.spring.dikishi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DilchipathvariablesApplication {

	public static void main(String[] args) {
		SpringApplication.run(DilchipathvariablesApplication.class, args);
	}

}
