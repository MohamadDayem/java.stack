package com.javastack.spring.dikishi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DilchipathvariablesApplicationTests {

	@Test
	void contextLoads() {
	}

}
