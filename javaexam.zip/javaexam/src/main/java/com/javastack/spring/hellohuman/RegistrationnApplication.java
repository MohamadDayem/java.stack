package com.javastack.spring.hellohuman;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegistrationnApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistrationnApplication.class, args);
	}

}
