public class testcafe {




    System.out.println(generalGreeting + customer1);
}
