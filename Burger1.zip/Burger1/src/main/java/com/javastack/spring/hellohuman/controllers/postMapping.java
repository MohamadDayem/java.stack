package com.javastack.spring.hellohuman.controllers;

public @interface postMapping {

}
